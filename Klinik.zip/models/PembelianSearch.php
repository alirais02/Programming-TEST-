<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Pembelian;

/**
 * PembelianSearch represents the model behind the search form of `app\models\Pembelian`.
 */
class PembelianSearch extends Pembelian
{
    public $nama_pasien;
    public $nama_pegawai;
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_pembelian', 'id_pasien', 'total_bayar', 'id_pegawai'], 'integer'],
            [['diagnosis', 'resep', 'tgl_pembelian', 'status', 'nama_pasien', 'nama_pegawai'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Pembelian::find();
        $query->leftJoin('pasien', 'pembelian.id_pasien = pasien.id_pasien');
        $query->leftJoin('pegawai', 'pembelian.id_pegawai = pegawai.id_pegawai');
        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_pembelian' => $this->id_pembelian,
            'id_pasien' => $this->id_pasien,
            'tgl_pembelian' => $this->tgl_pembelian,
            'total_bayar' => $this->total_bayar,
            'id_pegawai' => $this->id_pegawai,
        ]);

        $query->andFilterWhere(['like', 'diagnosis', $this->diagnosis])
            ->andFilterWhere(['like', 'resep', $this->resep])
            ->andFilterWhere(['like', 'status', $this->status])
            ->andFilterWhere(['like', 'tgl_pembelian', $this->tgl_pembelian])
            ->andFilterWhere(['like', 'pasien.nama_pasien', $this->nama_pasien])
            ->andFilterWhere(['like', 'pegawai.nama_pegawai', $this->nama_pegawai]);

        return $dataProvider;
    }
}
