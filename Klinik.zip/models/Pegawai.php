<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "pegawai".
 *
 * @property int $id_pegawai
 * @property string $nama_pegawai
 * @property int $nip
 * @property string $jenis_kelamin
 * @property string $jabatan
 * @property string $status_pegawai
 * @property string $alamat
 * @property int $no_hp
 *
 * @property Pembelian[] $pembelians
 */
class Pegawai extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'pegawai';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama_pegawai', 'jenis_kelamin', 'jabatan', 'status_pegawai', 'alamat', 'no_hp'], 'required'],
            [['nip', 'no_hp'], 'integer'],
            [['nama_pegawai', 'jabatan', 'status_pegawai'], 'string', 'max' => 100],
            [['jenis_kelamin'], 'string', 'max' => 20],
            [['alamat'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_pegawai' => 'Id Pegawai',
            'nama_pegawai' => 'Nama Pegawai',
            'nip' => 'Nip',
            'jenis_kelamin' => 'Jenis Kelamin',
            'jabatan' => 'Jabatan',
            'status_pegawai' => 'Status Pegawai',
            'alamat' => 'Alamat',
            'no_hp' => 'No Hp',
        ];
    }

    /**
     * Gets query for [[Pembelians]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPembelians()
    {
        return $this->hasMany(Pembelian::class, ['id_pegawai' => 'id_pegawai']);
    }

    public static function getAllPegawai(){
        $pegawai = Pegawai::find()->all();
        $pegawai = ArrayHelper::map($pegawai, 'id_pegawai', 'nama_pegawai');
        return $pegawai;
    }
}
