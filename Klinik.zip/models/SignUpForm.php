<?php

namespace app\models;

use Yii;
use yii\base\Model;

class SignUpForm extends Model
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    public $username;
    public $password;
    public $authKey;
    public $accessToken;
    public $status;
    public $role;
    public $time_create;
    public $time_update;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username'], 'unique', 'targetClass' => '\app\models\User', 'message' => 'This username has already been taken.'],
            [['username', 'password', 'authKey', 'accessToken', 'status', 'role', 'time_create', 'time_update'], 'required'],
            [['status'], 'integer'],
            [['time_create', 'time_update'], 'safe'],
            [['username'], 'string', 'max' => 10],
            [['password', 'authKey', 'accessToken'], 'string', 'max' => 100],
            [['role'], 'string', 'max' => 50],
        ];
    }

    public function signup()
    {
        if ($this->validate()) {
            $user = new User();
            $user->username = $this->username;
            $user->password = Yii::$app->security->generatePasswordHash($this->password);
            $user->authKey = $this->authKey;
            $user->accessToken = $this->accessToken;
            $user->status = $this->status;
            $user->role = $this->role;
            $user->time_create = $this->time_create;
            $user->time_update = $this->time_update;
            return $user->save();
        }

        return false;
    }
    
}
