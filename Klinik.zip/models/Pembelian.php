<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "pembelian".
 *
 * @property int $id_pembelian
 * @property int $id_pasien
 * @property string $diagnosis
 * @property string $resep
 * @property string $tgl_pembelian
 * @property int $total_bayar
 * @property string $status
 * @property int $id_pegawai
 *
 * @property Pasien $pasien
 * @property Pegawai $pegawai
 */
class Pembelian extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'pembelian';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_pasien', 'diagnosis', 'resep', 'tgl_pembelian', 'total_bayar', 'status', 'id_pegawai'], 'required'],
            [['id_pasien', 'total_bayar', 'id_pegawai'], 'integer'],
            [['tgl_pembelian'], 'safe'],
            [['diagnosis', 'resep'], 'string', 'max' => 255],
            [['status'], 'string', 'max' => 100],
            [['id_pasien'], 'exist', 'skipOnError' => true, 'targetClass' => Pasien::class, 'targetAttribute' => ['id_pasien' => 'id_pasien']],
            [['id_pegawai'], 'exist', 'skipOnError' => true, 'targetClass' => Pegawai::class, 'targetAttribute' => ['id_pegawai' => 'id_pegawai']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_pembelian' => 'Id Pembelian',
            'id_pasien' => 'Id Pasien',
            'diagnosis' => 'Diagnosis',
            'resep' => 'Resep',
            'tgl_pembelian' => 'Tgl Pembelian',
            'total_bayar' => 'Total Bayar',
            'status' => 'Status',
            'id_pegawai' => 'Id Pegawai',
        ];
    }

    /**
     * Gets query for [[Pasien]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPasien()
    {
        return $this->hasOne(Pasien::class, ['id_pasien' => 'id_pasien']);
    }

    /**
     * Gets query for [[Pegawai]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPegawai()
    {
        return $this->hasOne(Pegawai::class, ['id_pegawai' => 'id_pegawai']);
    }
}
