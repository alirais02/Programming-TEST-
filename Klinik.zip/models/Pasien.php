<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "pasien".
 *
 * @property int $id_pasien
 * @property string $nama_pasien
 * @property string $tempat_lahir
 * @property string $tanggal_lahir
 * @property string $alamat
 * @property int $no_hp
 * @property string $status_pasien
 *
 * @property Pembelian[] $pembelians
 */
class Pasien extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'pasien';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama_pasien', 'tempat_lahir', 'tanggal_lahir', 'jenis_kelamin', 'alamat', 'no_hp', 'status_pasien'], 'required'],
            [['tanggal_lahir'], 'safe'],
            [['no_hp'], 'integer'],
            [['nama_pasien', 'tempat_lahir', 'status_pasien'], 'string', 'max' => 100],
            [['alamat'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_pasien' => 'Id Pasien',
            'nama_pasien' => 'Nama Pasien',
            'tempat_lahir' => 'Tempat Lahir',
            'tanggal_lahir' => 'Tanggal Lahir',
            'jenis_kelamin' => 'Jenis Kelamin',
            'alamat' => 'Alamat',
            'no_hp' => 'No Hp',
            'status_pasien' => 'Status Pasien',
        ];
    }

    /**
     * Gets query for [[Pembelians]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPembelians()
    {
        return $this->hasMany(Pembelian::class, ['id_pasien' => 'id_pasien']);
    }

    public static function getAllPasien(){
        $pasien = Pasien::find()->all();
        $pasien = ArrayHelper::map($pasien, 'id_pasien', 'nama_pasien', 'tanggal_lahir');
        return $pasien;
    }
}
