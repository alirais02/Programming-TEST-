<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\Pegawai $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="pegawai-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
        <div class="col-md-5">
        <?= $form->field($model, 'nama_pegawai')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-md-5"><?= $form->field($model, 'nip')->textInput() ?></div>
        <div class="col-md-2">
        <?= $form->field($model, 'jenis_kelamin')->radioList(['Laki-laki' => 'Laki-laki', 'Perempuan' => 'Perempuan']) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md">
        <?= $form->field($model, 'jabatan')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-md">
        <?= $form->field($model, 'status_pegawai')->dropDownList([$model->status_pegawai, 'Pegawai Tetap' => 'Pegawai Tetap', 'Kontrak' => 'Kontrak']) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md">
        <?= $form->field($model, 'alamat')->textarea(['maxlength' => true, 'rows'=>5, 'cols'=>30]) ?>
        </div>
        <div class="col-md">
        <?= $form->field($model, 'no_hp')->textInput(['type' => 'number']) ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-sm btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
