<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\Pasien $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="pasien-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nama_pasien')->textInput(['maxlength' => true]) ?>

    <div class="row">
        <div class="col-md">
        <?= $form->field($model, 'tempat_lahir')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-md">
        <label for="">Tanggal Lahir</label>
        <p>
            <input type="date" name="Pasien[tanggal_lahir]" id="tanggal_lahir" value="<?= $model->tanggal_lahir ?>" class="form-control">
        </p>
        </div>
    </div>

    <div class="row">
        <div class="col-md">
        <?= $form->field($model, 'jenis_kelamin')->radioList(['Laki-laki' => 'Laki-laki', 'Perempuan' => 'Perempuan']) ?>
        </div>
        <div class="col-md">
        <?= $form->field($model, 'alamat')->textarea(['maxlength' => true, 'rows'=>5, 'cols'=>30]) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md">
        <?= $form->field($model, 'no_hp')->textInput(['type' => 'number']) ?>
        </div>
        <div class="col-md">
        <?= $form->field($model, 'status_pasien')->dropDownList([$model->status_pasien,'Reguler' => 'Reguler', 'BPJS Kesehatan' => 'BPJS Kesehatan']) ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-sm btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
