<?php

use app\models\Pasien;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\jui\DatePicker;
/** @var yii\web\View $this */
/** @var app\models\PasienSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Pasien';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="pasien-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Tambah Pasien', ['create'], ['class' => 'btn btn-sm btn-success']) ?>
    </p>

    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'nama_pasien',
            'tempat_lahir',
            [
                'attribute' => 'tanggal_lahir',
                'format' => ['date', 'php:d-M-Y'],
                'filter' => Html::activeInput('date', $searchModel, 'tanggal_lahir', ['class' => 'form-control']),
            ],            
            [
                'attribute' => 'jenis_kelamin',
                'filter' => Html::activeDropDownList($searchModel, 'jenis_kelamin', ['Laki-laki' => 'Laki-laki', 'Perempuan' => 'Perempuan'], ['class' => 'form-control', 'prompt' => 'Semua'])
            ],
            //'alamat',
            //'no_hp',
            [
                'attribute' => 'status_pasien',
                'filter' => Html::activeDropDownList($searchModel, 'status_pasien', ['Reguler' => 'Reguler', 'BPJS Kesehatan' => 'BPJS Kesehatan'], ['class' => 'form-control', 'prompt' => 'Semua'])
            ],
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, Pasien $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id_pasien' => $model->id_pasien]);
                 }
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>

</div>
