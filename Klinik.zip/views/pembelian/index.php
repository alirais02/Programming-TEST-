<?php

use app\models\Pembelian;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;
/** @var yii\web\View $this */
/** @var app\models\PembelianSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Pembelian';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="pembelian-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Buat Pembelian', ['create'], ['class' => 'btn btn-sm btn-success']) ?>
    </p>

    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            [
                'attribute' => 'nama_pasien',
                'value' => function($model){
                    return $model->pasien->nama_pasien;
                }
            ],
            // 'pasien.nama_pasien',
            'diagnosis',
            'resep',
            [
                'attribute' => 'tgl_pembelian',
                'format' => ['date', 'php:d-M-Y'],
                'filter' => Html::activeInput('date', $searchModel, 'tgl_pembelian', ['class' => 'form-control']),
            ],
            [
                'attribute' => 'total_bayar',
                'format' => ['currency', 'Rp'],
            ],
            [
                'attribute' => 'status',
                'filter' => Html::activeDropDownList($searchModel, 'status', ['Belum Bayar' => 'Belum Bayar', 'Sudah Bayar' => 'Sudah Bayar'], ['class' => 'form-control', 'prompt' => 'Semua'])
            ],
            [
                'attribute' => 'nama_pegawai',
                'value' => function($model){
                    return $model->pegawai->nama_pegawai;
                }
            ],
            // 'pegawai.nama_pegawai',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, Pembelian $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id_pembelian' => $model->id_pembelian]);
                 }
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>

</div>
