<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\Pembelian $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="pembelian-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_pasien')->label('Nama Pasien')->dropDownList($nama_pasien, ['prompt' => 'Pilih Nama Pasien...']) ?>
    <div class="row">
        <div class="col-md">
        <?= $form->field($model, 'diagnosis')->textarea(['maxlength' => true, 'rows' => 5, 'cols' => 30]) ?>
        </div>
        <div class="col-md">
        <?= $form->field($model, 'resep')->textInput(['maxlength' => true, 'rows' => 5, 'cols' => 30]) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md">
            <label for="">Tanggal Pembelian</label>
            <input type="date" name="Pembelian[tgl_pembelian]" id="tgl_pembelian" value="<?= $model->tgl_pembelian ?>" class="form-control">
        </div>
        <div class="col-md">
        <?= $form->field($model, 'total_bayar')->textInput(['type' => 'number']) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md">
        <?= $form->field($model, 'status')->dropDownList([$model->status, 'Belum Bayar' => 'Belum Bayar', 'Sudah Bayar' => 'Sudah Bayar']) ?>
        </div>
        <div class="col-md">
        <?= $form->field($model, 'id_pegawai')->label('Nama Pegawai')->dropDownList($nama_pegawai, ['prompt' => 'Pilih Nama Pegawai...']) ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-sm btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
