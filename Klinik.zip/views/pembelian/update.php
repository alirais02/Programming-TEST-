<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Pembelian $model */

$this->title = 'Update Pembelian: ' . $model->tgl_pembelian;
$this->params['breadcrumbs'][] = ['label' => 'Pembelian', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->pasien->nama_pasien, 'url' => ['view', 'id_pembelian' => $model->id_pembelian]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="pembelian-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'nama_pasien' => $nama_pasien,
        'nama_pegawai' => $nama_pegawai
    ]) ?>

</div>
