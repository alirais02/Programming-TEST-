<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Sign Up';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="site-signup">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Please fill out the following fields to register:</p>

    <div class="row">
        <div class="col-lg-5">
            <?php $form = ActiveForm::begin(['id' => 'signup-form',
                'fieldConfig' => [
                    'template' => "{label}\n{input}\n{error}",
                    'labelOptions' => ['class' => 'col-lg-1 col-form-label mr-lg-3'],
                    'inputOptions' => ['class' => 'col-lg-3 form-control'],
                    'errorOptions' => ['class' => 'col-lg-7 invalid-feedback'],
                ],
            ]);?>

            <?= $form->field($model, 'username')->textInput(['autofocus' => true]) ?>

            <?= $form->field($model, 'password')->passwordInput() ?>

            <?= $form->field($model, 'authKey')->label(false)->hiddenInput(['value' => Yii::$app->security->generateRandomString()])->label(false) ?>

            <?= $form->field($model, 'accessToken')->label(false)->hiddenInput(['value' => Yii::$app->security->generateRandomString()])->label(false) ?>

            <?= $form->field($model, 'status')->label(false)->hiddenInput(['value' => '10'])?>

            <?= $form->field($model, 'role')->label(false)->hiddenInput(['value' => '10'])?>

            <?= $form->field($model, 'time_create')->label(false)->hiddenInput(['value' => time()])?>

            <?= $form->field($model, 'time_update')->label(false)->hiddenInput(['value' => time()])?>

            <div class="form-group">
                <?= Html::submitButton('Sign Up', ['class' => 'btn btn-primary', 'name' => 'signup-button']) ?>
            </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
