<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index(){
        return view('login');
    }

    public function authenticate(Request $request){
        $credentials = $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);

        if(Auth::attempt($credentials)){


            if(auth()->user()->level === 'admin'){
                $request->session()->regenerate();
                return redirect()->intended('/admin/beranda');
            }else{
                $request->session()->regenerate();
                return redirect()->intended('/beranda');
            }
        }

        return back()->with('loginError', 'Silakan Ulangi');

    }

    public function logout(Request $request){
        Auth::logout();
        $request->session()->flush();
        return redirect('/');
    }
}
