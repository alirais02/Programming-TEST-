<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row" style="margin-top:100px;">
            <div class="col justify-content-center text-center">
                <h3>Daftar</h3>
            </div>
        </div><br>
        <div class="row justify-content-center">
            <div class="col-md-4 text-center">
                <div class="card border-0">
                    <div class="card-body">
                        <form action="/daftar" method="post">
                            @csrf
                            <div class="form-group">
                                <input type="text" name="name" placeholder="Nama" class="form-control" required>
                            </div><br>
                            <div class="form-group">
                                <input type="email" name="email" placeholder="Email" class="form-control" required>
                            </div><br>
                            <div class="form-group">
                                <input type="password" name="password" placeholder="Password" class="form-control" required>
                                <input type="hidden" name="level" placeholder="pengguna" value="pengguna">
                            </div><br>
                            <input type="submit" value="Daftar" name="login" class="btn btn-sm btn-success form-control mb-2">
                            <a href="/login" class="btn btn-sm btn-secondary form-control mb-2">Kembali</a>
                        </form>
                        <br>
                        <p><small>Sudah memiliki akun? <a href="/login">Silakan Login</a></small></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>