

<div class="container">
    <div class="row">
        <div class="col">

        </div>
    </div>
</div>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Program\Laravel\penjualan\resources\views/home.blade.php ENDPATH**/ ?>